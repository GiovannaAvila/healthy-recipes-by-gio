const search=document.getElementById('search');
const filters=document.querySelectorAll('.filter');
const cards=document.querySelectorAll('.card');
let active='all';
function update(){
  const term=(search.value||'').toLowerCase();
  cards.forEach(card=>{
    const matchesCategory=active==='all'||card.dataset.category===active;
    const matchesSearch=card.dataset.title.includes(term)||card.innerText.toLowerCase().includes(term);
    card.style.display=matchesCategory&&matchesSearch?'block':'none';
  });
}
filters.forEach(btn=>btn.addEventListener('click',()=>{
  filters.forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  active=btn.dataset.filter;
  update();
}));
search.addEventListener('input',update);
